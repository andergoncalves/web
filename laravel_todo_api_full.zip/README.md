# Laravel Todo API

### Passo a passo para rodar o projeto

1. Suba os containers:
   ```bash
   docker-compose up -d --build
   ```

2. Acesse o container do app:
   ```bash
   docker-compose exec app bash
   ```

3. Instale o Laravel dentro do container:
   ```bash
   composer create-project laravel/laravel .
   ```

4. Copie os arquivos de `app/`, `routes/`, `database/migrations/` deste pacote para dentro do container.

5. Rode as migrations:
   ```bash
   php artisan migrate
   ```

6. Acesse a API em: [http://localhost:8000/api](http://localhost:8000/api)
